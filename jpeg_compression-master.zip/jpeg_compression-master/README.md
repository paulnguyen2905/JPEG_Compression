# Nén ảnh với thuật toán jpeg



### Install requirements

Run the following command

```
pip install -r requirements.txt
```

### Run program

Run the following command

```
python run.py
```


## Authors

* **18520286 – Trần Xuân Hưng** 
* **18520507 – Nguyễn Phước Bình** 
* **18521427 – Nguyễn Hoàng Thiên** 
		
		

